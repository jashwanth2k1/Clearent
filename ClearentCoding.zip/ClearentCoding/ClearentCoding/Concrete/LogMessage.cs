﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ClearentCoding.Concrete
{
    class LogMessage
    {
        public static void WriteToFile(string errorMessage)
        {
            File.WriteAllText(@"C:\Temp\Error.txt", errorMessage);
        }
    }
}
