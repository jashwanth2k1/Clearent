﻿using System;
using System.Collections.Generic;
using System.Text;
using ClearentCoding.Abstract;
using ClearentCoding.Entity;

namespace ClearentCoding.Concrete
{
    public class InterestCalculation : IInterestCalculation
    {
        
        public decimal Balance { get; set; } = 100;

        public decimal CalculateInterest(decimal interestRate)
        {
            decimal interestAmount;
            try
            {
                interestAmount = Balance * interestRate;
            }
            catch (Exception ex)
            {
                LogMessage.WriteToFile(ex.Message.ToString());
                throw ex;
            }
            return interestAmount;
        }

        public List<Person> GetTotalInterest(int perCnt, int wltCnt, List<string> cardTypes)
        {
            List<Person> p = new List<Person>();
            List<Wallet> wal = new List<Wallet>();
            List<Cards> crd = new List<Cards>();
            Person pr = new Person();
            Wallet w = new Wallet();
            Cards c = new Cards();
            Decimal d = 0; Decimal intrt = 0;
            InterestRate obj = new InterestRate();
            DCInterestRate dd = new DCInterestRate();
            MCInterestRate mc = new MCInterestRate();
            VisaInterestRate vc = new VisaInterestRate();
            try
            {
                for (int pCnt = 1; pCnt <= perCnt; pCnt++)
                {
                    pr = new Person();
                    pr.Id = pCnt;
                    pr.Name = "Bogus Name";
                    w = new Wallet();

                    for (int wCnt = 1; wCnt <= wltCnt; wCnt++)
                    {
                        crd = new List<Cards>();
                        foreach (string item in cardTypes)
                        {
                            c = new Cards();
                            switch (item)
                            {
                                case Constants.DCTYPE:
                                    c.InterestAmount = CalculateInterest(obj.GetInterestRate(dd));
                                    c.Type = c.Name = item;
                                    break;
                                case Constants.VISATYPE:
                                    c.InterestAmount = CalculateInterest(obj.GetInterestRate(vc));
                                    c.Type = c.Name = item;
                                    break;
                                case Constants.MCTYPE:
                                    c.InterestAmount = CalculateInterest(obj.GetInterestRate(mc));
                                    c.Type = c.Name = item;
                                    break;
                                default:
                                    break;
                            }
                            pr.TotalInterest = pr.TotalInterest + c.InterestAmount;
                            crd.Add(c);
                        }

                        w.TotalInterest = w.TotalInterest + pr.TotalInterest;
                        w.WalletID = wCnt;
                        w.Cards = crd;
                        wal.Add(w);
                    }

                    pr.Wallet = wal;
                    p.Add(pr);
                }

            }
            catch (Exception ex)
            {
                LogMessage.WriteToFile(ex.Message.ToString());
                throw ex;
            }
           
            return p;
        }
    }

    public class DCInterestRate
    {
        public virtual decimal GetInterestRate()
        {
            return 0.01M;
        }

    }

    public class InterestRate
    {
        public decimal GetInterestRate(DCInterestRate di)
        {
            return di.GetInterestRate();
        }

    }
    public class MCInterestRate : DCInterestRate
    {
        public override decimal GetInterestRate()
        {
            return 0.05M;
        }
    }

    public class VisaInterestRate : DCInterestRate
    {
        public override decimal GetInterestRate()
        {
            return 0.10M;
        }
    }

}
