﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.NetworkInformation;
using System.Text;

namespace ClearentCoding.Concrete
{
    public static class Constants
    {
        public const string DCTYPE = "DC";
        public const string MCTYPE = "MC";
        public const string VISATYPE = "VISA";
    }
}
