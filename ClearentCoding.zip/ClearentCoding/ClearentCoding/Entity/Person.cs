﻿using System;
using System.Collections.Generic;
using System.Text;
namespace ClearentCoding.Entity
{
    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public IList<Wallet> Wallet { get; set; }
        public decimal TotalInterest { get; set; }
    }

    public class Wallet
    {
        public int WalletID { get; set; }
        public decimal TotalInterest { get; set; }
        public IList<Cards> Cards { get; set; }
    }

    public class Cards
    {
        public string Type { get; set; }
        public string Name { get; set; }
        public decimal InterestAmount { get; set; }

    }

    public class CardTypes
    {
        public string CardType { get; private set; }
        public CardTypes(string type)
        {
            CardType = type;
        }
    }

   
   
 }

