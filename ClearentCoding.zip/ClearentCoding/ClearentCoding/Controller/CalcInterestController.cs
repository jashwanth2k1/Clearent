﻿using ClearentCoding.Entity;
using ClearentCoding.Concrete;
using System;
using System.Collections.Generic;
using System.Text;
using ClearentCoding.Abstract;

namespace ClearentCoding.Controller
{
    public class CalcInterestController
    {
        public void CalculateInterest()
        {
            InterestCalculation mic = new InterestCalculation();
            List<Person> plst = new List<Person>();
            List<string> list = new List<string>();
            list.Add("VISA");
            list.Add("MC");
            list.Add("DC");
            //below function returns values(list) based on specified parameters, further logic
            //can be added to get the required output 
            plst = mic.GetTotalInterest(1, 1, list);
        }
       
    }
}
