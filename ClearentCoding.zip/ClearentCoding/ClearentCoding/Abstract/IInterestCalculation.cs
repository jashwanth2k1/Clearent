﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClearentCoding.Abstract
{
    public interface  IInterestCalculation
    {
        decimal Balance { get; set; }
        decimal CalculateInterest(decimal interestRate);
    }
}
